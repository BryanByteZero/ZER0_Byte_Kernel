# ScriptFlashKernelSimpleFalcon
Kernel Zip Layout Falcon A simple script to flash ONLY a kernel with ramdisk (zImage-dtb) with edify and bmunlock (that find correct partition and do a dd to flash).
